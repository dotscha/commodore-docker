
 Please note that not all decrunchers in this folder has not yet been updated
to use the new file format for crunched files that exomizer 3 generates by
default. Those decrunchers are krilldecr.s exostreamdecr1.s exostreamdecr2.s.

 To generate files that are compatible with exomizer 2 you must now add the
flag -P0 to the exomizer commandline.
