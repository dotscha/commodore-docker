#ifndef _CODE68K_HPP
#define _CODE68K_HPP

/* Declare this in a header file so CLang++ does not complain
   about unused inline functions: */

# include "cppops.h"
DefCPPOps_Mask(tSuppFlags)

#endif /* _CODE68K_HPP */
