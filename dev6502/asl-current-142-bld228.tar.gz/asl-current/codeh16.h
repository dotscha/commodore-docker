#ifndef _CODE_H16_H
#define _CODE_H16_H
/* codeh16.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* AS - Target Hitachi H16                                                   */
/*                                                                           */
/*****************************************************************************/

extern void codeh16_init(void);

#endif /* _CODE_H16_H */
