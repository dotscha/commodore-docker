#ifndef _CODEHMCS400_H
#define _CODEHMCS400_H
/* codehmcs400.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator Hitachi/Renesas HMCS400                                     */
/*                                                                           */
/*****************************************************************************/

extern void codehmcs400_init(void);
#endif /* _CODEHMCS400_H */
