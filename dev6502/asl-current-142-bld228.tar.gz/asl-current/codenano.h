#ifndef _CODENANO_H
#define _CODENANO_H
/* codenano.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator HP Nanoprocessor                                            */
/*                                                                           */
/*****************************************************************************/

extern void codenano_init(void);
#endif /* _CODENANO_H */
