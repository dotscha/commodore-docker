#ifndef _CODE97C241_H
#define _CODE97C241_H
/* code97c241.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator TLCS-9000                                                   */
/*                                                                           */
/* Historie:                                                                 */
/*                                                                           */
/*****************************************************************************/

extern void code97c241_init(void);
#endif /* _CODE97C241_H */
