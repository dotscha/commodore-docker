#ifndef _CODE9331_H
#define _CODE9331_H
/* code9331.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Code Generator Toshiba TC9331                                             */
/*                                                                           */
/*****************************************************************************/

extern void code9331_init(void);

#endif /* _CODE9331_H */
