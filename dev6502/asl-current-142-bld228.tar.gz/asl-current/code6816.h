#ifndef _CODE6816_H
#define _CODE6816_H
/* code6816.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegeneratormodul CPU16                                                  */
/*                                                                           */
/* Historie: 15.10.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code6816_init(void);
#endif /* _CODE6816_H */
