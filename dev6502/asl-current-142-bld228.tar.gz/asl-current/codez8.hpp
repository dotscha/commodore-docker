#ifndef _CODEZ8_HPP
#define _CODEZ8_HPP

/* Declare this in a header file so CLang++ does not complain
   about unused inline functions: */

# include "cppops.h"
DefCPPOps_Mask(tCoreFlags)

#endif /* _CODEZ8_HPP */
