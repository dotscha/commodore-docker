#ifndef _CODEZ8000_H
#define _CODEZ8000_H
/* codez8000.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator Zilog Z8000                                                 */
/*                                                                           */
/*****************************************************************************/

extern void codez8000_init(void);
#endif /* _CODEZ8000_H */
