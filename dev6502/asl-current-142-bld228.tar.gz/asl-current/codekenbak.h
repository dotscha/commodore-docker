#ifndef _CODEKENBAK_H
#define _CODEKENBAK_H
/* codekenbak.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS                                                                        */
/*                                                                           */
/* Codegenerator KENBAK(-1)                                                  */
/*                                                                           */
/*****************************************************************************/

extern void codekenbak_init(void);

#endif /* _CODEKENBAK_H */
