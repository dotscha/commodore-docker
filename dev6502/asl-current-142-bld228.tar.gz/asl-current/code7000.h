#ifndef _CODE7000_H
#define _CODE7000_H
/* code7000.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator SH7x00                                                      */
/*                                                                           */
/* Historie: 25.12.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code7000_init(void);
#endif /* _CODE7000_H */
