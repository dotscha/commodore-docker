#ifndef _CODE85_H
#define _CODE85_H
/* code85.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator 8080/8085                                                   */
/*                                                                           */
/* Historie: 24.10.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code85_init(void);
#endif /* _CODE85_H */
