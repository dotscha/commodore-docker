/* codekcp3.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator xilinx kcpsm3                                               */
/*                                                                           */
/*****************************************************************************/

extern void codekcpsm3_init(void);
