#ifndef _CODE370_H
#define _CODE370_H
/* code370h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator 370-Familie                                                 */
/*                                                                           */
/* Historie: 10.12.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code370_init(void);
#endif /* _CODE370_H */
