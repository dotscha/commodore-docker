#ifndef _CODETMS7_H
#define _CODETMS7_H
/* codetms7.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator TMS7000-Familie                                             */
/*                                                                           */
/* Historie: 26.2.1997 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void codetms7_init(void);
#endif /* _CODETMS7_H */
