#ifndef _CODE9900_H
#define _CODE9900_H
/* code9900.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator TMS99xx                                                     */
/*                                                                           */
/* Historie:  9. 3.1997 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code9900_init(void);
#endif /* _CODE9900_H */
