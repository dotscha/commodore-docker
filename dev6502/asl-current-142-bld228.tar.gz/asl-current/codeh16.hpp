#ifndef _CODEH16_HPP
#define _CODEH16_HPP

/* Declare this in a header file so CLang++ does not complain
   about unused inline functions: */

# include "cppops.h"
DefCPPOps_Enum(tFormat)

#endif /* _CODEH16_HPP */
