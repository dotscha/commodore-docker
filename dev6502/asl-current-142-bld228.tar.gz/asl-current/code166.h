#ifndef _CODE166_H
#define _CODE166_H
/* code166.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* AS-Codegenerator Siemens 80C16x                                           */
/*                                                                           */
/* Historie: 11.11.1996 (alaaf) Grundsteinlegung                             */
/*                                                                           */
/*****************************************************************************/

extern void code166_init(void);
#endif /* _CODE166_H */
