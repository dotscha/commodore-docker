#ifndef _CODEH8_5_H
#define _CODEH8_5_H
/* codeh8_5.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator H8/500-Familie                                              */
/*                                                                           */
/* Historie: 24.12.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void codeh8_5_init(void);
#endif /* _CODEH8_5_H */
