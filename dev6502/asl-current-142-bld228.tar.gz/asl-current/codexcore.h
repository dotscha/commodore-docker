#ifndef _CODEXCORE_H
#define _CODEXCORE_H
/* codexcore.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS                                                                        */
/*                                                                           */
/* Code Generator for XMOS XCore Processor                                   */
/*                                                                           */
/*****************************************************************************/

extern void codexcore_init(void);
#endif /* _CODEXCORE_H */
