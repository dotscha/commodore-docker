#ifndef _CODE3205X_H
#define _CODE3205X_H
/*
 * AS-Portierung
 *
 * AS-Codegeneratormodul fuer die Texas Instruments TMS320C5x-Familie
 *
 * 19.08.96: Erstellung
 */

extern void code3205x_init(void);
#endif /* _CODE3205X_H */
