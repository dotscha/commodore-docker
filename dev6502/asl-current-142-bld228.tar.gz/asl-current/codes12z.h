#ifndef _CODES12Z_H
#define _CODES12Z_H
/* codes12z.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS                                                                        */
/*                                                                           */
/* Code Generator NXP S12Z                                                   */
/*                                                                           */
/*****************************************************************************/

extern void codes12z_init(void);
#endif /* _CODES12Z_H */
