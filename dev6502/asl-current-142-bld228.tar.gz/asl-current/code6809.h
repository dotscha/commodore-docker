#ifndef _CODE6809_H
#define _CODE6809_H
/* code6809.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator 6809/6309                                                   */
/*                                                                           */
/* Historie: 10.10.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code6809_init(void);
#endif /* _CODE6809_H */
